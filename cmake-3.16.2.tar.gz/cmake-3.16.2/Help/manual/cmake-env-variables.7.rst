.. cmake-manual-description: CMake Environment Variables Reference

cmake-env-variables(7)
**********************

.. only:: html

   .. contents::

This page lists environment variables that have special
meaning to CMake.

For general information on environment variables, see the
:ref:`Environment Variables <CMake Language Environment Variables>`
section in the cmake-language manual.


Environment Variables that Control the Build
============================================

.. toctree::
   :maxdepth: 1

   /envvar/CMAKE_BUILD_PARALLEL_LEVEL
   /envvar/CMAKE_CONFIG_TYPE
   /envvar/CMAKE_GENERATOR
   /envvar/CMAKE_GENERATOR_INSTANCE
   /envvar/CMAKE_GENERATOR_PLATFORM
   /envvar/CMAKE_GENERATOR_TOOLSET
   /envvar/CMAKE_MSVCIDE_RUN_PATH
   /envvar/CMAKE_NO_VERBOSE
   /envvar/CMAKE_OSX_ARCHITECTURES
   /envvar/DESTDIR
   /envvar/LDFLAGS
   /envvar/MACOSX_DEPLOYMENT_TARGET
   /envvar/PackageName_ROOT
   /envvar/VERBOSE

Environment Variables for Languages
===================================

.. toctree::
   :maxdepth: 1

   /envvar/ASM_DIALECT
   /envvar/ASM_DIALECTFLAGS
   /envvar/CC
   /envvar/CFLAGS
   /envvar/CSFLAGS
   /envvar/CUDACXX
   /envvar/CUDAFLAGS
   /envvar/CUDAHOSTCXX
   /envvar/CXX
   /envvar/CXXFLAGS
   /envvar/FC
   /envvar/FFLAGS
   /envvar/RC
   /envvar/RCFLAGS
   /envvar/SWIFTC

Environment Variables for CTest
===============================

.. toctree::
   :maxdepth: 1

   /envvar/CMAKE_CONFIG_TYPE
   /envvar/CTEST_INTERACTIVE_DEBUG_MODE
   /envvar/CTEST_OUTPUT_ON_FAILURE
   /envvar/CTEST_PARALLEL_LEVEL
   /envvar/CTEST_PROGRESS_OUTPUT
   /envvar/CTEST_USE_LAUNCHERS_DEFAULT
   /envvar/DASHBOARD_TEST_FROM_CTEST
